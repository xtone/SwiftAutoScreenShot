//
//  SwiftAutoScreenShot.h
//  SwiftAutoScreenShot
//
//  Created by 合田竜志 on 2023/01/20.
//

#import <Foundation/Foundation.h>

//! Project version number for SwiftAutoScreenShot.
FOUNDATION_EXPORT double SwiftAutoScreenShotVersionNumber;

//! Project version string for SwiftAutoScreenShot.
FOUNDATION_EXPORT const unsigned char SwiftAutoScreenShotVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftAutoScreenShot/PublicHeader.h>


